#include <iostream>
using namespace std;

int main(){
    int highest[7] = {};
    int lowest[7] = {};
    
    for(int day=1; day<=7; day++){
        cout << "Enter the Highest Temerature on the day " << day << ": ";
        cin >> highest[day-1];
        
        cout << "Enter the Lowest Temerature on the day " << day << ": ";
        cin >> lowest[day-1];

        cout << "\n";
    }

    cout << "\n\n";
    cout << "Day | Highest | Lowest\n";
    cout << "--- | ------- | ------\n";
    for(int day=1; day<=7; day++){
        cout << " " << day << "  |   " << highest[day-1] << "    |   " << lowest[day-1] << "  \n";
    }
}