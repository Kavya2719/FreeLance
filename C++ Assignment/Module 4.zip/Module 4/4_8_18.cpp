// Lab8-2.cpp - displays a person's total
// earnings before retirement at age 65,
// using annual raise rates of 3%, 4%, and 5%
// Created/revised by <your name> on <current date>

#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

int main()
{
    int currentSalary = 0;
    double newSalary = 0.0;

    cout << fixed << setprecision(0);

    while(true){
        cout << "Current salary as a whole number (enter a negative value to exit) : ";
        cin >> currentSalary;
        cout << endl;

        if(currentSalary < 0) break;

        for (double rate = 0.03; rate < 0.07; rate += 0.01)
        {
            newSalary = currentSalary;

            for (int year = 1; year <= 3; ++year)
            {
                newSalary *= (1 + rate);
                cout << "Amount raise for year " << year << " at " << rate*100 << "% annual raise : " << newSalary - currentSalary << endl;
            } // end for
            cout << endl;
        } // end for
    }
    
    return 0;
} // end of main function