#include <iostream>
using namespace std;

int main(){
    int n;
    cout << "Enter the number of students: "; cin >> n;
    cout << endl;

    string grades = "";
    for(int i=0; i<n; i++){
        int midterm, final;

        cout << "Enter the mid-term scores of student " << i+1 << ": ";
        cin >> midterm;

        cout << "Enter the final scores of student " << i+1 << ": ";
        cin >> final;
        cout << endl;

        int total = midterm + final;

        char grade;
        if(total >= 360) grade = 'A';
        else if(total >= 320) grade = 'B';
        else if(total >= 280) grade = 'C';
        else if(total >= 240) grade = 'D';
        else grade = 'F';

        grades.push_back(grade); 
    }

    for(int student=0; student<n; student++) cout << "Grade of Student " << student+1 << ": " << grades[student] << endl;
}