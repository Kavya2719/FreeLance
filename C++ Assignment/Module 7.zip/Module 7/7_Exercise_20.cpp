#include <iostream>
using namespace std;

int main(){
    string code = "";
    cout << "Enter your 3-letter region code: ";
    cin >> code;
    
    bool isValid = true;
    if(code.length() == 3){
        if(code[0] == 'A' || code[0] == 'B'){
            if(code[1] > '9' || code[1] < '0') isValid = false;
            else if(code[2] > '9' || code[2] < '0') isValid = false;
        }else isValid = false;
    }else isValid = false;

    if(isValid) cout << "The shipping charge for region " << code[0] << " is $" << code[1] << code[2] << ".\n";
    else cout << "Provided region code is invalid.\n";
}