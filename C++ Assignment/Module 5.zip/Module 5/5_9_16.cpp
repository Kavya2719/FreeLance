#include <iostream>
using namespace std;

int main(){
    cout << "Number | Square | Cube\n";
    cout << "------ | ------ | ----\n";
    for(int number=10; number<=14; number++){
        cout << "  " << number << "   |  " << number*number << "   | " << number*number*number << "\n";
    }
}