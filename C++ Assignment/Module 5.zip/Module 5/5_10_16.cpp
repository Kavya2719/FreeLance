#include <iostream>
using namespace std;

// Function declaration
double calOverTimePay(int no_of_hours, double hourly_pay_rate);

int main()
{
    // Declaring variables
    int no_of_hours;
    double hourly_pay_rate, gross_pay, overtime_pay;

    while (true)
    {
        gross_pay = 0.0;
        overtime_pay = 0.0;

        // gettinbg the no of hours worked value entered by the user
        cout << "\nEnter no of hours worked (enter negative value to exit): ";
        cin >> no_of_hours;

        if(no_of_hours < 0)
        {
            cout << ":: Exiting ::" << endl;
            break;
        }
        // Getting the pay rate entered by the user
        cout << "Enter hourly pay rate: $";
        cin >> hourly_pay_rate;

        // calculating the total gross pay
        gross_pay = no_of_hours * hourly_pay_rate;
        // calling the function to calculate the over time pay
        overtime_pay = calOverTimePay(no_of_hours, hourly_pay_rate);

        // Displaying the total gross pay
        cout << "Total Gross pay is $" << gross_pay + overtime_pay << endl;
    }

    return 0;
}

// this function will calculate the overtime pay
double calOverTimePay(int no_of_hours, double hourly_pay_rate)
{
    // Declaring the variable
    double overtime_pay = 0.0;

    // based on the worked hours calculates the overtime pay and return
    if (no_of_hours > 37){
        if(no_of_hours < 50) overtime_pay = (no_of_hours - 37) * hourly_pay_rate / 2;
        else overtime_pay = 13 * hourly_pay_rate / 2;    
    }
    if (no_of_hours > 50) overtime_pay += (no_of_hours - 50) * hourly_pay_rate;
    
    return overtime_pay;
}
