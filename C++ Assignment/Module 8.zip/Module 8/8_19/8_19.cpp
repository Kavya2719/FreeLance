#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
using namespace std;

int main(){
  double payroll;

  ofstream outFile;
  outFile.open("Introduction19.txt", ios::app);
  outFile << fixed << setprecision(2);
  
  if (outFile.is_open())
  {
    while(1){
      cout << "Enter the company's payroll amount (enter negative value to exit): $";
      cin >> payroll;

      if(payroll < 0) break;

      outFile << payroll << endl;
    }
  }
  else cout << "Introduction19.txt file could not be opened" << endl;

  outFile.close();
  
  return 0;
}