#include <iostream>
#include <string>
#include <iomanip>
#include <fstream>
using namespace std;

int main(){
  double price;

  ofstream outFile;
  outFile.open("Introduction20.txt", ios::app);
  outFile << fixed << setprecision(2);
  
  if (outFile.is_open())
  {
    while(1){
      cout << "Enter the price amount (enter negative value to exit): $";
      cin >> price;

      if(price < 0) break;

      outFile << price << endl;
    }
  }
  else cout << "Introduction20.txt file could not be opened" << endl;

  outFile.close();
  
  return 0;
}