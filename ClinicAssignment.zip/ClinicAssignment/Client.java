
class Client extends Clinic{
	int clientID;
	String clientName;
	// and other client details.

	// checks the availability of all the physiotherapists on the upcoming days, for an appointment.
	public void checkAvailaibility(){
		super.checkAvailaibility();
	}

	// books an appointment of the physiotherapist with the client on the mentioned date and time.
	public void bookAppointment(){
		super.bookAppointment("BookingDetails");
	}

	// cancels an already existing appointment.
	public void cancelAppointment(){
		super.cancelAppointment("BookingID");
	}

	// reschedules an already existing appointment.
	public void rescheduleAppointment(){
		super.rescheduleAppointment("BookingID");
	}

	// returns all the details of the client.
	public void getClientDetails(){}

	// returns all the previous appointments data of the client.
	public void getAppointmentsHistory(){}
};
