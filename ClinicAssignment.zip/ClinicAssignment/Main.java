public class Main {
    public static void main(String[] args) {
        Client client1 = new Client();
        System.out.println("Executed Successfully");
    }
}