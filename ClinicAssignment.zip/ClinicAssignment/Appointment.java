class Appointment {
    public String bookingID;
    public int date;
    public int clientID;
    public int physiotherapistID;

    // and any other required details
}