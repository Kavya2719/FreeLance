public class Clinic {
    Appointment [] appointments; // array of appointments containing details of an appointment.

	// fetches the details of all the upcoming appointments for all physiotherapists.
	protected void getAllAppointments(){}

	// sends a confirmation email stating that the booking has been confirmed.
	protected void sendConfirmationEmail(String clientEmailAddress, String bookingDetails){}

	// books an appointment of the physiotherapist with the client on the mentioned date and time.
	public void bookAppointment(String bookingDetails){}
	
	// cancels an already existing appointment.
	public void cancelAppointment(String bookingID){}

	// reschedules an already existing appointment.
	public void rescheduleAppointment(String bookingID){}

	// checks the availability of all the physiotherapists on the upcoming days.
	public void checkAvailaibility(){}

	// fetches the upcoming appointment for this physiotherapist.
	public void getAppointments(int physiotherapistID){}
}
