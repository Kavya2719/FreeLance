
class Physiotherapist extends Clinic{
	int physiotherapistID;
	String physiotherapistName;
	// and other details.

	// fetches the upcoming appointment for this physiotherapist.
	public void getAppointments(){
		super.getAppointments(physiotherapistID);
	}

	// cancels an already existing appointment.
	public void cancelAppointment(){
		super.cancelAppointment("BookingID");
	}

	// reschedules an already existing appointment.
	public void rescheduleAppointment(){
		super.rescheduleAppointment("BookingID");
	}

	// fetches all the necessary client info and his medical history.
	public void getClientInfo(Client client){
		client.getClientDetails();
	}
};