class ClinicManager extends Clinic {
    String clinicManagerName;
    // and other details here

    // All the methods required for the functionality of a clinic manager have already been inherited from class Clinic
}