
class Receptionist extends Clinic{
	String receptionistName;
	// and other details here

	// fetches the details of all the upcoming appointments for all physiotherapists.
	public void getAllAppointments(){
		super.getAllAppointments();
	}

	// cancels an already existing appointment.
	public void cancelAppointment(){
		super.cancelAppointment("BookingID");
	}

	// reschedules an already existing appointment.
	public void rescheduleAppointment(){
		super.rescheduleAppointment("BookingID");
	}

	// sends a reminder to the client for his/her upcoming appointment.
	public void sendReminder(String clientEmailAddress, String bookingDetails){}
};
